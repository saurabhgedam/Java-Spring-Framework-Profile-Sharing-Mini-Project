package edu.sjsu.cmpe275.aop;

import static org.junit.Assert.*;


import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.sjsu.cmpe275.aop.exceptions.AccessDeniedExeption;
import edu.sjsu.cmpe275.aop.exceptions.NetworkException;

public class ProfileServiceTest {

    /***
     * These are dummy test cases. You may add test cases based on your own need.
     */
	public ProfileService profileService;
	@Before
	public void prepare()
	{
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
        profileService =  (ProfileService) context.getBean("profileService");
	}
	
    @Test
    public void testUserShareOwnProfile() 
    { 
    	try {
			profileService.shareProfile("Alice", "Alice", "Bob");
			assertTrue("Success", true);
		}
    	catch (AccessDeniedExeption e) {
			assertFalse("Failed", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @Test
    public void testShareSomeOnesProfile() {
    	try {
			profileService.shareProfile("Alice", "Carl", "Bob");
			assertFalse("Failed", true);
		} catch (AccessDeniedExeption e) {
			assertTrue("Success", true);
    		} 
    	catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testShareFriendsProfile(){
    	try {
			profileService.shareProfile("Alice", "Alice", "Bob");
			profileService.shareProfile("Bob", "Alice", "Carl");
			assertTrue("Success", true);
		} catch (AccessDeniedExeption e){
			assertFalse("Failed", true);
    		} 
    	catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testShareOwnProfileWithSelf(){
    	try {
			profileService.shareProfile("Alice", "Alice", "Alice");
			assertTrue("Success", true);
		}
    	catch (AccessDeniedExeption e) {
			assertFalse("Failed", true);
    	}
    	catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testShareAlreadySharedProfile()
    {
    	try 
    	{
			profileService.shareProfile("Alice", "Alice", "Bob");
			profileService.shareProfile("Bob", "Alice", "Bob");
			profileService.shareProfile("Alice", "Alice", "Bob");
			assertTrue("Success", true);
		} catch (AccessDeniedExeption e) 
    	{
			assertFalse("Failed", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    @Test
    public void testReadUnsharedProfile()
    {
    	try 
    	{
			profileService.readProfile("Alice", "Carl");
			assertFalse("Failed", true);
		} catch (AccessDeniedExeption e) 
    	{
			System.out.println(e.getMessage());
			assertTrue("Success", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testReadOwnProfile()
    {
    	try 
    	{
    		profileService.readProfile("Alice", "Alice");
			assertTrue("Success", true);
		} catch (AccessDeniedExeption e) 
    	{
			assertFalse("Failed", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testReadSharedProfile()
    {
    	try 
    	{
    		profileService.shareProfile("Alice", "Alice", "Bob");
    		profileService.readProfile("Bob", "Alice");
			assertTrue("Success", true);
		} catch (AccessDeniedExeption e) 
    	{
			assertFalse("Failed", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testReadPseudoSharedProfile()
    {
    	try 
    	{
    		profileService.shareProfile("Alice", "Alice", "Bob");
    		profileService.shareProfile("Bob", "Alice", "Carl");
    		profileService.readProfile("Carl", "Alice");
			assertTrue("Success", true);
		} catch (AccessDeniedExeption e) 
    	{
			assertFalse("Failed", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testReadAfterUnshare()
    {
    	try 
    	{
    		profileService.shareProfile("Alice", "Alice", "Bob");
    		profileService.unshareProfile("Alice", "Bob");
			profileService.readProfile("Bob", "Alice");
			assertFalse("Failed", true);
		} catch (AccessDeniedExeption e) 
    	{
			System.out.println(e.getMessage());
			assertTrue("Success", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testUnshareOwnProfile()
    {
    	try 
    	{
    		profileService.unshareProfile("Alice", "Alice");
			assertTrue("Success", true);
		} catch (AccessDeniedExeption e) 
    	{
			assertFalse("Failed", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testUnshareProfileAlreadyNotShared()
    {
    	try 
    	{
    		profileService.unshareProfile("Alice", "Bob");
			assertFalse("Failed", true);
		} catch (AccessDeniedExeption e) 
    	{
			System.out.println(e.getMessage());
			assertTrue("Success", true);
    	} catch (NetworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
   

    	@Test
    	public void testCase1() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	}

    	@Test
    	public void testCase2() {

    		try {
    			profileService.shareProfile("Alice", "Carl", "Bob");
    			fail();
    		}

    		catch (Exception e) {
    			
    		}
    	}
    	
    	@Test
    	public void testCase3() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.readProfile( "Alice","Alice");
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	}
    	

    	@Test
    	public void testCase4() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.readProfile( "Bob","Alice");
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	}

    	@Test
    	public void testCase5() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.readProfile( "Alice","Bob");
    			fail();
    			}

    		catch (Exception e) {
    			
    		}
    	}

    	@Test
    	public void testCase6() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.readProfile( "Carl","Alice");
    			fail();
    		}

    		catch (Exception e) {
    			
    		}
    	}


    	@Test
    	public void testCase7() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.shareProfile("Bob", "Alice", "Carl");
    			profileService.readProfile( "Carl","Alice");
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	}

    	@Test
    	public void testCase8() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.shareProfile("Bob", "Alice", "Carl");
    			profileService.readProfile( "Carl","Bob");
    			fail();
    		}

    		catch (Exception e) {
    			
    		}
    	}
    	
    	
    	@Test
    	public void testCase9() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.shareProfile("Bob", "Carl", "Alice");
    			fail();
    		}

    		catch (Exception e) {
    			
    		}
    	

    	}
    	
    	@Test
    	public void testCase10() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.shareProfile("Bob", "Alice", "Carl");
    			profileService.readProfile( "Carl","Alice");
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	
    		}

    	@Test
    	public void testCase11() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.shareProfile("Bob", "Alice", "Carl");
    			profileService.unshareProfile( "Alice","Alice");
    			profileService.unshareProfile( "Alice","Bob");
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	

    		}
    	
    	@Test
    	public void testCase12() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.shareProfile("Bob", "Alice", "Carl");
    			profileService.readProfile( "Alice","Carl");
    			fail();
    		}

    		catch (Exception e) {
    			
    		}
    	}

    	@Test
    	public void testCase13() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Bob");
    			profileService.shareProfile("Bob", "Alice", "Carl");
    			profileService.unshareProfile( "Alice","Carl");
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	}

    	@Test
    	public void testCase14() {

    		try {
    			profileService.shareProfile("Alice", "Alice", "Alice");
    			
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	}
    	
    	@Test
    	public void testCase15() {

    		try {
    			profileService.unshareProfile("Alice", "Alice");			
    			assertTrue(true);
    		}

    		catch (Exception e) {
    			fail();
    		}
    	}


    }