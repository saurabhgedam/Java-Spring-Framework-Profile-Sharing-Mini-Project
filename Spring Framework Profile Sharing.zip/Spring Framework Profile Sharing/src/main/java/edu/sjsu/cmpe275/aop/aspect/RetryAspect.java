package edu.sjsu.cmpe275.aop.aspect;
import org.aspectj.lang.annotation.Aspect;  

import edu.sjsu.cmpe275.aop.exceptions.NetworkException;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.ProceedingJoinPoint; 

@Aspect
public class RetryAspect {

	@Around("execution(public void edu.sjsu.cmpe275.aop.ProfileService.*(..))")
	public void dummyAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.printf("Prior to the executuion of the metohd %s\n", joinPoint.getSignature().getName());
		
		try{
			joinPoint.proceed();
		}
			catch(NetworkException a){
				
				try{
					joinPoint.proceed();
				}
				
				catch(NetworkException b){
					try{
						joinPoint.proceed();
						
					}
					catch(NetworkException c){
						throw c;
					}
				}
			} 
		catch (Exception someOtherException){
		throw someOtherException;
		}
			
	}
}
