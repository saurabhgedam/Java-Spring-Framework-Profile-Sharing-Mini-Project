package edu.sjsu.cmpe275.aop.aspect;


import edu.sjsu.cmpe275.aop.exceptions.AccessDeniedExeption;

import org.aspectj.lang.annotation.Aspect;  // if needed

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.aspectj.lang.JoinPoint;  // if needed
import org.aspectj.lang.annotation.Before;  // if needed


@Aspect
public class AuthorizationAspect {
    /***
     * Following is a dummy implementation of this aspect.
     * You are expected to provide an actual implementation based on the requirements, including adding/removing advises as needed.
     */
	
	Map<String,List<String>> prolog = new HashMap<String, List<String>>(); 
	@Before("execution(public void edu.sjsu.cmpe275.aop.ProfileService.shareProfile(..))")
	public void beforeShareProfile(JoinPoint joinPoint)  throws Throwable {
		System.out.printf("Before the executuion of the method %s\n", joinPoint.getSignature().getName());		
		Object[] param = joinPoint.getArgs();
		
		if(prolog.get(param[0])==null){
			List<String> proList = new ArrayList<String>();
			 proList.add(param[0].toString());
			prolog.put(param[0].toString(), proList);
		}
		
		if(prolog.get(param[1]) == null) {
			List<String> proList = new ArrayList<String>();
			proList.add(param[1].toString());
            prolog.put(param[1].toString(), proList);
        }
		
		if(prolog.get(param[2]) == null) {
			List<String> proList = new ArrayList<String>();
			proList.add(param[2].toString());
			prolog.put(param[2].toString(), proList);
        }
		
		if (prolog.get(param[0]) != null && prolog.get(param[0]).contains(param[1].toString())) {
            prolog.get(param[2]).add(param[1].toString());
		}
		else{
			throw new AccessDeniedExeption("Access not granted");
		}

	}
	
	@Before("execution(public void edu.sjsu.cmpe275.aop.ProfileService.unshareProfile(..))")
	public void beforeUnshareProfile(JoinPoint joinPoint) throws Throwable {
		System.out.printf("Before the executuion of the method %s\n", joinPoint.getSignature().getName());
		Object[] param = joinPoint.getArgs();
		if(param[1]!=param[0]){
			if (prolog.get(param[1]) != null && prolog.get(param[1]).contains(param[0].toString())) {
				List<String> proList = prolog.get(param[1]);
	            proList.remove(proList.indexOf(param[0].toString()));
	        } 
			else {
	            throw new AccessDeniedExeption("Access not granted");
	        }
		}
		
	}
	
	 @Before("execution(public edu.sjsu.cmpe275.aop.Profile edu.sjsu.cmpe275.aop.ProfileService.readProfile(..))")
	    public void beforeReadProfile(JoinPoint joinPoint) throws Throwable {
	        System.out.printf("Before the execution of the method %s\n", joinPoint.getSignature().getName());
	        Object[] param = joinPoint.getArgs();
	    
	        if(prolog.get(param[0])==null){
				List<String> proList = new ArrayList<String>();
				 proList.add(param[0].toString());
				prolog.put(param[0].toString(), proList);
			}
			
			if(prolog.get(param[1]) == null) {
				List<String> proList = new ArrayList<String>();
				proList.add(param[1].toString());
	            prolog.put(param[1].toString(), proList);
	        }

	        if (prolog.get(param[0]) != null && prolog.get(param[0]).contains(param[1].toString())) {
	        		System.out.println(prolog.get(param[0]).contains(param[1].toString()));
	        } else {
	            throw new AccessDeniedExeption("");
	          }
	    }
	
}