package edu.sjsu.cmpe275.aop;

public class Profile {

}
